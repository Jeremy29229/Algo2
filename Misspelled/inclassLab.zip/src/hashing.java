
public class hashing
{
	private static int hash(String str)
	{
		int h = 0;
		for(int i = 0; i < str.length(); i++)
		{
			//h += str.charAt(i) * (i + 1);
			//h += (str.charAt(i)) * Math.pow(10, str.length());
//			if(h == 0)
//			{
//				int off = offset;
//				char val[] = value;
//				int len = count;
//				
//				for(int i = 0; i < len; i++)
//				{
//					h = 31 * h + val[off++];
//				}
//			}
//			hash = h
		}
		
		return h;
	}
	
	public static void main(String[] args)
	{
		System.out.println(hash("Jeremy"));
		System.out.println(hash("Timn"));
		System.out.println(hash("Tinm"));
		System.out.println(hash("Tayls"));
		System.out.println(hash("Jon"));
		System.out.println(hash("alex"));
		System.out.println(hash("karl"));

	}

}
