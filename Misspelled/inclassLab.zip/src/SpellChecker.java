

public interface SpellChecker {
	SpellCorrection checkWord(String word);
}
