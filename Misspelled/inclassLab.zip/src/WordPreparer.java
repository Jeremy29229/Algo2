

public interface WordPreparer {
	Word prepare(String word);
}
