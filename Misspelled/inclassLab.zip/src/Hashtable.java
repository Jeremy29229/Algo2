import java.util.Iterator;

public class Hashtable<K, V>
{
	private Entry<K,V>[] values;
	private int size;
	
	@SuppressWarnings("unchecked")
	public Hashtable(int initialCapacity)
	{
		values = (Entry<K,V>[])new Entry[initialCapacity];
	}
	
	/**
	 * #3b. Implement this (1 point)
	 * 
	 * @param key
	 * @param value
	 */
	public void put(K key, V value)
	{		
			int hash = key.hashCode() % values.length;
			if(values[hash] == null)
			{
				values[hash] = new Entry<K, V>(key, value);
			}
			else
			{
				Entry<K, V> current = values[hash];
				Entry<K, V> previous = null;
				boolean foundValue = false;
				while(current != null && !current.key.equals(key))
				{
					if(current.key == key)
					{
						current.data = value;
						foundValue = true;
					}
					previous = current;
					current = current.next;
				}
				if(!foundValue)
				{
					
				}
				previous.next = new Entry<K, V>(key, value);
			}	
	}
	
	/**
	 * #3b. Implement this (1 point)
	 * @param key
	 * @return
	 */
	public V get(K key)
	{
		V value = null;
		Entry<K, V> current = null;
		
		if(values[key.hashCode()] != null)
		{
			current = values[key.hashCode()];
		}
		
		while(current != null && current.key != key)
		{
			current = current.next;
		}
		
		if(current != null && current.data != null)
		{
			value = current.data;
		}
		
		return value;
	}

	/**
	 * #3c.  Implement this. (1 point)
	 * 
	 * @param key
	 * @return
	 */
	public V remove(K key)
	{
		V value = null;
		Entry<K, V> current = null;
		current = values[key.hashCode()];
		Entry<K, V> previous = null;
		
		if(current != null)
		{
			while(current.key != key)
			{
				previous = current;
				current = current.next; 
			}
		}
		
		if(current!= null && current.key == key)
		{
			if(current.next != null)
			{
				previous.next = current.next;
			}
			else
			{
				previous.next = null;
			}
		}
		
		return value;
	}
	
	public int size()
	{
		return size;
	}
	
	public boolean containsKey(K key)
	{
		return this.get(key) != null; 
	}

	public Iterator<V> values()
	{
		return new Iterator<V>()
		{
			private int count = 0;
			private Entry<K, V> currentEntry;
			
			{
				while ((currentEntry = values[count]) == null && count < values.length)
				{
					count++;
				}
			}

			@Override
			public boolean hasNext()
			{
				return count < values.length;
			}

			@Override
			public V next()
			{
				V toReturn = currentEntry.data;
				currentEntry = currentEntry.next;
				while ( currentEntry == null && ++count < values.length && (currentEntry = values[count]) == null );
				return toReturn;
			}

			@Override
			public void remove(){}
		};
	}
	
	private static class Entry<K, V>
	{
		private K key;
		private V data;
		private Entry<K,V> next;
		
		public Entry(K key, V data)
		{
			this.key = key;
			this.data = data;
		}
		
		public String toString()
		{
			return "{" + key + "=" + data + "}";
		}
	}
}