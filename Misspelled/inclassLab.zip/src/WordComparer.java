import java.util.Set;


public interface WordComparer {
	Set<Word> getRelatedWords(String word);
}
